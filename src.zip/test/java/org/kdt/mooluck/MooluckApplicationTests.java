package org.kdt.mooluck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MooluckApplicationTests {

	@Test
	void contextLoads() {
	}

}
